<?php
include("conexao.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    $email = $_POST['email'];
    $cnpj = $_POST['cnpj'];
    $nome = $_POST['nome'];
    $tel = $_POST['tel'];
    $tipo_usuario = 'empresa';

    if (empty($usuario) || empty($senha) || empty($email) || empty($cnpj) || empty($nome) || empty($tel)) {
        echo json_encode(['status' => 'error', 'message' => 'Por favor, preencha todos os campos.']);
        exit;
    }
    

    $sql = "SELECT * FROM empresas WHERE cnpj = ? OR email = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ss", $cnpj, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Empresa ou Email já cadastrado.']);
    } else {
        $sql = "INSERT INTO empresas (usuario, senha, cnpj, nome, tel, email, tipo_usuario) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("sssssss", $usuario, $senha, $cnpj, $nome, $tel, $email, $tipo_usuario);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Empresa cadastrada com sucesso!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Erro ao cadastrar empresa.']);
        }
    }

    $stmt->close();
    $conexao->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método de requisição inválido.']);
}
?>

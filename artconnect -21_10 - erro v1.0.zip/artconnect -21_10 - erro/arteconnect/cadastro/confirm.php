<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verificar o tipo de usuário a partir do formulário enviado
    if (isset($_POST['tipo_usuario'])) {
        $tipo_usuario = $_POST['tipo_usuario'];

        // Redirecionar para a página de cadastro correspondente
        switch ($tipo_usuario) {
            case 'artista':
                header("Location: cadastro_artista.php");
                break;
            case 'comum':
                header("Location: cadastro_comum.php");
                break;
            case 'empresa':
                header("Location: cadastro_empresa.php");
                break;
            default:
                echo "Erro: Tipo de usuário inválido.";
        }
    } else {
        echo "Erro: Nenhum tipo de usuário selecionado.";
    }
} else {
    echo "Erro: Método de requisição inválido.";
}
?>,,,,
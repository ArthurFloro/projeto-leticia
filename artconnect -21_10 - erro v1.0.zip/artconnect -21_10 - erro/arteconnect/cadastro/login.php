<?php
include("conexao.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loginIdentidade = $_POST['loginIdentidade'];
    $senha = $_POST['senha'];

    if (empty($loginIdentidade) || empty($senha)) {
        echo json_encode(['status' => 'error', 'message' => 'Por favor, preencha todos os campos.']);
        exit;
    }

    // Verificar o usuário nas tabelas pessoas, artistas e empresas
    $sql = "
        SELECT usuario, senha, tipo_usuario FROM pessoas WHERE email = ? OR usuario = ?
        UNION ALL
        SELECT usuario, senha, tipo_usuario FROM artistas WHERE email = ? OR usuario = ?
        UNION ALL
        SELECT usuario, senha, tipo_usuario FROM empresas WHERE email = ? OR usuario = ?
    ";
    
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ssssss", $loginIdentidade, $loginIdentidade, $loginIdentidade, $loginIdentidade, $loginIdentidade, $loginIdentidade);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verifica a senha
        if (password_verify($senha, $user['senha'])) {
            session_start();
            $_SESSION['usuario'] = $user['usuario'];
            $_SESSION['tipo_usuario'] = $user['tipo_usuario'];

            // Redireciona de acordo com o tipo de usuário
            if ($user['tipo_usuario'] === 'comum') {
                echo json_encode(['status' => 'success', 'message' => 'Login bem-sucedido!', 'tipo_usuario' => 'comum']);
            } elseif ($user['tipo_usuario'] === 'artista' || $user['tipo_usuario'] === 'empresa') {
                echo json_encode(['status' => 'success', 'message' => 'Login bem-sucedido!', 'tipo_usuario' => 'artista']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Senha incorreta.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Usuário ou email não encontrado.']);
    }

    $stmt->close();
    $conexao->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método de requisição inválido.']);
}

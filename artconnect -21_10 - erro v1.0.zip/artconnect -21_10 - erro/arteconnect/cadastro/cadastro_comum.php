<?php
include("conexao.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    $email = $_POST['email'];
    $tipo_usuario = 'comum';

    if (empty($usuario) || empty($senha) || empty($email)) {
        echo json_encode(['status' => 'error', 'message' => 'Por favor, preencha todos os campos.']);
        exit;
    }

    // Verifica se o usuário ou o email já estão cadastrados
    $sql = "SELECT * FROM pessoas WHERE usuario = ? OR email = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ss", $usuario, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Usuário ou Email já cadastrado.']);
    } else {
        // Insere o novo usuário no banco de dados
        $sql = "INSERT INTO pessoas (usuario, senha, email, tipo_usuario) VALUES (?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ssss", $usuario, $senha, $email, $tipo_usuario);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Usuário cadastrado com sucesso!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Erro ao cadastrar usuário.']);
        }
    }

    $stmt->close();
    $conexao->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método de requisição inválido.']);
}
?>

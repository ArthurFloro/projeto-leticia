<?php
include("conexao.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    $email = $_POST['email'];
    $area = $_POST['area'];
    $estilo = $_POST['estilo'];
    $tipo_usuario = 'artista';

    if (empty($usuario) || empty($senha) || empty($email) || empty($area) || empty($estilo)) {
        echo json_encode(['status' => 'error', 'message' => 'Por favor, preencha todos os campos.']);
        exit;
    }

    $sql = "SELECT * FROM artistas WHERE usuario = ? OR email = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ss", $usuario, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Usuário ou Email já cadastrado.']);
    } else {
        $sql = "INSERT INTO artistas (usuario, senha, email, area, estilo, tipo_usuario) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ssssss", $usuario, $senha, $email, $area, $estilo, $tipo_usuario);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Usuário cadastrado com sucesso!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Erro ao cadastrar usuário.']);
        }
    }

    $stmt->close();
    $conexao->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Método de requisição inválido.']);
}
?>
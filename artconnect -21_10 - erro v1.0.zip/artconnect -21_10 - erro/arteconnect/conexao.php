<?php
$servername = "localhost";
$username = "root";  // Substitua com seu nome de usuário
$password = "Flr280906@"; // Substitua com sua senha
$dbname = "artconnect"; // Substitua com o nome do seu banco de dados

// Criar conexão
$conexao = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conexao->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Falha na conexão: ' . $conexao->connect_error]));
}
?>

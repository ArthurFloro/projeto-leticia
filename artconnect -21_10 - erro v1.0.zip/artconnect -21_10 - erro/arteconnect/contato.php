<?php
session_start();
include 'conexao.php';  // Assumindo que a conexão com o banco de dados está em outro arquivo

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_SESSION['usuario_id'];
    $nome = $_POST['nome'];
    $bio = $_POST['bio'];

    // Verificar se há uma nova foto de perfil sendo enviada
    if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
        $foto_nome = $_FILES['foto_perfil']['name'];
        $foto_tmp = $_FILES['foto_perfil']['tmp_name'];
        $foto_destino = 'uploads/' . $foto_nome;

        // Mover o arquivo para a pasta "uploads"
        move_uploaded_file($foto_tmp, $foto_destino);

        // Atualizar a foto de perfil no banco de dados
        $query = "UPDATE usuarios SET nome = ?, bio = ?, foto_perfil = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sssi', $nome, $bio, $foto_destino, $usuario_id);
    } else {
        // Caso não haja nova foto, atualiza somente os outros dados
        $query = "UPDATE usuarios SET nome = ?, bio = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ssi', $nome, $bio, $usuario_id);
    }

    if ($stmt->execute()) {
        echo "Perfil atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar perfil!";
    }
}
?>

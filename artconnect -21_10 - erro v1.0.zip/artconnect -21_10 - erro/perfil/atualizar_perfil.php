<?php
session_start();
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_SESSION['id'];
    $nome = $_POST['nome'];
    $bio = $_POST['bio'];

    if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
        $foto_nome = $_FILES['foto_perfil']['name'];
        $foto_tmp = $_FILES['foto_perfil']['tmp_name'];
        $foto_destino = 'uploads/' . $foto_nome;

        move_uploaded_file($foto_tmp, $foto_destino);

        $query = "UPDATE usuarios SET nome = ?, bio = ?, foto_perfil = ? WHERE id = ?";
        $stmt = $conexao->prepare($query);
        $stmt->bind_param('sssi', $nome, $bio, $foto_destino, $usuario_id);
    } else {
        $query = "UPDATE usuarios SET nome = ?, bio = ? WHERE id = ?";
        $stmt = $conexao->prepare($query);
        $stmt->bind_param('ssi', $nome, $bio, $usuario_id);
    }

    if ($stmt->execute()) {
        $_SESSION['foto_perfil'] = $foto_destino;
        echo json_encode(['status' => 'success', 'message' => 'Perfil atualizado com sucesso!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Erro ao atualizar perfil!']);
    }

    $stmt->close();
    $conexao->close();
}
?>
